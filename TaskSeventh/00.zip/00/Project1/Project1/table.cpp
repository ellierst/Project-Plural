#include "table.h"

FlightTable::FlightTable(int numCities) : numCities(numCities) {
    flights = new Node * [numCities];
    for (int i = 0; i < numCities; ++i) {
        flights[i] = nullptr;
    }
}

FlightTable::~FlightTable() {
    for (int i = 0; i < numCities; ++i) {
        Node* current = flights[i];
        while (current) {
            Node* temp = current;
            current = current->next;
            delete temp;
        }
    }
    delete[] flights;
}

void FlightTable::addFlight(const std::string& fromCity, const std::string& toCity) {
    int fromIndex = getCityIndex(fromCity);
    Node* newNode = new Node(toCity);
    newNode->next = flights[fromIndex];
    flights[fromIndex] = newNode;
}

bool FlightTable::canReachDestination(const std::string& start, const std::string& destination, int maxTransfers) {
    int startIndex = getCityIndex(start);
    int destIndex = getCityIndex(destination);
    return canReachHelper(startIndex, destIndex, maxTransfers);
}

int FlightTable::getCityIndex(const std::string& city) {
    // Temporary implementation to return city index
    return 0;
}

bool FlightTable::canReachHelper(int start, int destination, int maxTransfers) {
    // Temporary implementation for checking if destination city can be reached
    return false;
}
