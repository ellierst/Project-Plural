#pragma once

#include <string>

struct Node {
    std::string city;
    Node* next;

    Node(const std::string& c) : city(c), next(nullptr) {}
};

class FlightTable {
private:
    Node** flights;
    int numCities;

public:
    FlightTable(int numCities);
    ~FlightTable();
    void addFlight(const std::string& fromCity, const std::string& toCity);
    bool canReachDestination(const std::string& start, const std::string& destination, int maxTransfers);

private:
    int getCityIndex(const std::string& city);
    bool canReachHelper(int start, int destination, int maxTransfers);
};
